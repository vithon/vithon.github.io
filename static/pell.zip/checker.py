import sys

old_n, old_k = 0, 0
count = 0
already = set()

while True:
	if (count & 0xFF) == 0:
		print count
	l = raw_input().strip()
	try:
		n, k = map(int, l.split())
	except:
		print "Format", l
		sys.exit(0)
	#if n <= old_n or k <= old_k:
		#print "Order"
		#sys.exit(-1)
	if n * (n + 1) * 2 != (n + k) * (n + k + 1):
		print "Value", l
		sys.exit(-2)
	if k in already:
		print "Duplicate", l
	already.add(k)
	old_n, old_k = n, k
	count += 1
