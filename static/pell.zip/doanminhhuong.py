'''
    Bai du thi giai toan bang Python
    Author : Doan Minh Huong
'''

b, c, d = 2, 6, 14

while 1:

    a = ( c - 1 ) * d / b
    b = ( a + 1 ) * d / c
    c = ( a - 1 ) * b / d
    d = ( c + 1 ) * b / a
    print b, a
    print d, c
