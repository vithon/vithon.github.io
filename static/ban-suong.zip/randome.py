###
#
# Battle Ship game sample player
#
# Author: Nguyen Thanh Nam
#
# Released to the public domain
#
###

import entity
import random

class RandomPlacePlayer(entity.Player):

	def name_ship(self, ship):
		n = repr(ship.__class__)
		return n[n.index('.') + 1 : -2]

	def on_hit(self, x, y):
		# dont care
		pass

	def orient_ship(self, ship):
		return entity.HORIZONTAL

	def place_ship(self, ship):
		while True:
			x = random.randint(0, self.ocean.width - 1)
			y = random.randint(0, self.ocean.height - 1)
			if not self.t_ocean:
				self.t_ocean = entity.Ocean(self.ocean.width, self.ocean.height)
			try:
				ship.place(self.t_ocean, x, y)
				return (x, y)
			except ValueError:
				pass

	def lock_missile(self, ship):
		return (random.randint(0, self.ocean.width - 1),
			random.randint(0, self.ocean.height - 1))	

def entry(name):
	p = RandomPlacePlayer(name)
	p.t_ocean = None
	return p