###
#
# Battle Ship web display
#
# Author: Nguyen Thanh Nam
#
# Released to the public domain
#
###

import urllib, urllib2
import entity
import os

SECRET_KEY = 'key'
URL = 'http://127.0.0.1:5000/update/%d?key=' + urllib.quote_plus(SECRET_KEY) + '&'

def build_url(kw):
	mid = int(os.environ['MATCH_ID'])
	data = urllib.urlencode(kw)
	return (URL % mid) + data

def request(kw):
	try:
		url = build_url(kw)
		print url
		urllib2.urlopen(url).read() != 'OK'
	except:
		raise

class WebView(object):

	def __init__(self):
		pass

	def init(self, game):
		request({'action': 'init_ocean', 'x': game.oceans[0].width, 'y': game.oceans[0].height})
		for sid in range(4):
			for pid in range(2):
				s = game.ships[pid][sid]
				o = s.orientation
				request({'action': 'orient_ship', 'pid': pid, 'sid': sid, 'o': o})
				x = s.x
				y = s.y
				if sid in (1, 2):
					if o == entity.VERTICAL:
						y -= 1
					else:
						x -= 1
				elif sid == 3:
					if o == entity.VERTICAL:
						y -= 2
					else:
						x -= 2
				request({'action': 'place_ship', 'pid': pid, 'sid': sid, 'x': x + pid * game.oceans[0].width, 'y': y})

	def lock_missile(self, game, pid, sid, x, y):
		request({'action': 'fire', 'pid': pid, 'sid': sid, 'x': x + (1-pid) * game.oceans[0].width, 'y': y})
		
	def end_turn(self, game):
		pass

	def disqualify(self, game, pid):
		request({'action': 'disqualify', 'pid': pid})

	def over(self, game):
		request({'action': 'over'})

	def winner(self, game, pid):
		request({'action': 'win', 'pid': pid})

def entry():
	return WebView()
