from multiprocessing import Process
n,k=0,0

def solve(n,k):
    while True:
        n,k=12*k+29*n+14,5*k+12*n+6
        print n,k

if __name__ == "__main__":
    p = Process(target=solve, args=(n,k,))
    p.start()
    n,k=k+k+5*n+2,k+n+n+1
    print n,k
    solve(n,k)
