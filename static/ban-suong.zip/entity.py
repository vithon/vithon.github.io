###
#
# Battle Ship game models
#
# Author: Nguyen Thanh Nam
#
# Released to the public domain
#
###

import array


HORIZONTAL = 0
VERTICAL   = 1

OVERBOUND = -1
EMPTY = 0
ANCHORED = 1
BOMBARDED = 2


class Ocean(object):

	def __init__(self, width, height):
		zeroes = [EMPTY] * width
		self.__map = [array.array('B', zeroes) for i in range(height)]
		self.__ships = {}
		self.width = width
		self.height = height

	def mark(self, x, y, value=BOMBARDED):
		if (x < 0) or (x >= self.width) or (y < 0) or (y >= self.height):
			return
		self.__map[y][x] = value

	def get_ship(self, x, y):
		return self.__ships.get((x, y), None)

	def anchor(self, ship, spots):
		for (x, y) in spots:
			if self.is_marked(x, y):
				raise ValueError("cannot anchor ship here")
		for (x, y) in spots:
			self.__ships[(x, y)] = ship
			self.mark(x, y, ANCHORED)

	def is_marked(self, x, y):
		if (x < 0) or (x >= self.width) or (y < 0) or (y >= self.height):
			return OVERBOUND
		return self.__map[y][x]

	def bombard(self, x, y):
		r = False
		if (x, y) in self.__ships:
			self.__ships[(x, y)].hit(x, y)
			r = True
		self.mark(x, y)
		return r


class Missile(object):

	def __init__(self):
		pass

	def land(self, x, y):
		return []


class SpotMissile(Missile):

	def land(self, x, y):
		return [(x, y)]


class HorizontalMissile(Missile):

	def land(self, x, y):
		return [(x-1, y), (x, y), (x+1, y)]


class VerticalMissile(Missile):

	def land(self, x, y):
		return [(x, y-1), (x, y), (x, y+1)]


class CrossMissile(Missile):

	def land(self, x, y):
		return [(x, y-1),
			(x-1, y), (x, y), (x+1, y),
			(x, y+1)]


class Ship(object):
	def __init__(self, orientation=HORIZONTAL, missile_clz=None):
		self.orientation = orientation
		self.__missile_clz = missile_clz
		self.__damage = set()
		self._area = 0
		n = repr(self.__class__)
		self.name = n[n.index('.') + 1 : -2]

	def fire(self, x, y):
		missile = self.__missile_clz()
		return missile.land(x, y)

	def _place(self, ocean, x, y):
		raise NotImplemented()

	def place(self, ocean, x, y):
		self.x = x
		self.y = y
		self._place(ocean, x, y)
	
	def hit(self, x, y):
		self.__damage.add((x, y))

	def sunk(self):
		return len(self.__damage) >= self._area

	def __repr__(self):
		return "%s--%d" % (self.name, self.orientation)

class Frigate(Ship):

	def __init__(self, orientation=HORIZONTAL):
		Ship.__init__(self, orientation, SpotMissile)
		self._area = 1

	def _place(self, ocean, x, y):
		ocean.anchor(self, [(x, y)])


class Destroyer(Ship):

	def __init__(self, orientation):
		if orientation == HORIZONTAL:
			mc = HorizontalMissile
		else:
			mc = VerticalMissile
		Ship.__init__(self, orientation, mc)
		self._area = 3

	def _place(self, ocean, x, y):
		spots = []
		if self.orientation == HORIZONTAL:
			for i in range(-1, 2):
				spots.append((x-i, y))
		else:
			for i in range(-1, 2):
				spots.append((x, y-i))
		ocean.anchor(self, spots)


class MissileCruiser(Ship):

	def __init__(self, orientation=HORIZONTAL):
		Ship.__init__(self, orientation, CrossMissile)
		self._area = 5

	def _place(self, ocean, x, y):
		spots = []
		if self.orientation == HORIZONTAL:
			for i in range(-2, 3):
				spots.append((x-i, y))
		else:
			for i in range(-2, 3):
				spots.append((x, y-i))
		ocean.anchor(self, spots)


class Player(object):

	def __init__(self, name):
		self.name = name

	def init_ocean(self, width, height):
		self.ocean = Ocean(width, height)

	def on_hit(self, x, y):
		pass

	def name_ship(self, ship):
		raise NotImplemented()

	def orient_ship(self, ship):
		raise NotImplemented()

	def place_ship(self, ship):
		raise NotImplemented()

	def lock_missile(self, ship):
		raise NotImplemented()
