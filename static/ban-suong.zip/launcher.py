#!/usr/bin/python

###
#
# Battle Ship game launcher
#
# Author: Nguyen Thanh Nam
#
# Released to the public domain
#
###

import sys
import time
import optparse
import entity


class Game(object):

	def __init__(self, view, player1, player2, width, height):
		self.players = [player1, player2]
		self.oceans = [entity.Ocean(width, height) for i in range(2)]
		self.view = view
		self.initialized = False
		self.over = False

	def init(self):
		self.ships = [[], []]
		for i in range(2):
			ocean = self.oceans[i]
			self.players[i].init_ocean(ocean.width, ocean.height)
			self.__place_ships(i)
		self.view.init(self)
		self.initialized = True

	def __place_ships(self, pid):
		self.ships[pid].append(entity.Frigate())
		self.ships[pid].append(entity.Destroyer(entity.HORIZONTAL))
		self.ships[pid].append(entity.Destroyer(entity.VERTICAL))
		temp_ship = entity.MissileCruiser()
		orient = self.players[pid].orient_ship(temp_ship)
		self.ships[pid].append(entity.MissileCruiser(orient))

		for ship in self.ships[pid]:
			try:
				oe = ship.orientation
				(x, y) = self.players[pid].place_ship(ship)
				ship.orientation = oe
				ship.place(self.oceans[pid], x, y)
				name = self.players[pid].name_ship(ship)
				ship.name = repr(name)
			except:
				#import traceback
				#traceback.print_exc()
				#print ship, ship.orientation
				self.view.disqualify(self, pid)
				self.over = True
				return

	def __turn(self):
		spots = [[], []]
		for sid in range(len(self.ships[0])):
			for pid in range(2):
				ship = self.ships[pid][sid]
				if ship.sunk():
					continue
				try:
					(x, y) = self.players[pid].lock_missile(ship)
				except:
					self.view.disqualify(self, pid)
					self.over = True
					return
				spots[pid].extend(ship.fire(x, y))
				self.view.lock_missile(self, pid, sid, x, y)
		for pid, p_spots in enumerate(spots):
			for (x, y) in p_spots:
				if self.oceans[1-pid].bombard(x, y):
					self.players[pid].on_hit(x, y)
		self.view.end_turn(self)

	def __all_sunk(self, pid):
		r = True
		for s in self.ships[pid]:
			r = r & s.sunk()
		return r

	def __is_over(self):
		if self.over:
			return True
		for pid in range(2):
			if self.__all_sunk(pid):
				self.over = True
				self.view.winner(self, 1-pid)
		return self.over

	def run(self, delay):
		if not self.initialized:
			return
		while not self.__is_over():
			time.sleep(delay)
			self.__turn()
		self.view.over(self)


def main():
	opt_parser = optparse.OptionParser()
	opt_parser.add_option("-1", dest="player_1")
	opt_parser.add_option("-2", dest="player_2")
	opt_parser.add_option("-l", "--live", dest="live", type=float, default=0.0)
	opt_parser.add_option("-x", "--width", dest="width", type=int, default=10)
	opt_parser.add_option("-y", "--height", dest="height", type=int, default=10)
	opt_parser.add_option("-v", "--view", dest="view", default="console")

	opts, junk = opt_parser.parse_args()
	if opts.player_1 is None or opts.player_2 is None:
		opt_parser.error("missing -1 or -2")

	# reset sys.argv
	sys.argv = ['launcher.py']
	
	player1_mod = __import__(opts.player_1)
	player2_mod = __import__(opts.player_2)

	player1 = player1_mod.entry("Player 1")
	player2 = player2_mod.entry("Player 2")

	view_mod = __import__(opts.view)
	view = view_mod.entry()

	game = Game(view, player1, player2, opts.width, opts.height)
	game.init()
	game.run(opts.live)

if __name__ == "__main__":
	main()
