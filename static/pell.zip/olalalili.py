MAX = 1000000
n = 1
k = 1
left = 2*n*n
x = k + n
right = x*x + k - n
res = left - right
_next = 0
count = 0

def check(n, k):
    left = 2*n*n
    x = k + n
    right = x*x + k - n
    if (left == right):
        return 1
    return 0

while n < MAX:
    if (res == 0):
        _next =  k*2
        while 1:
            print n, k 
            #count = count + 1
            #print count

            _next = (n << 2) + _next + 2
            n = _next + n
            k = _next >> 1
        break
    else:
        if (res < 0):
            n += 1
            res = res + 2*(n-k)
        else:
            k += 1
            res = res - 2*(k+n)
            #right = right + 2*(k+n)        
