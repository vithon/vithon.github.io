###
#
# Battle Ship game sample player
#
# Author: Nguyen Thanh Nam
#
# Released to the public domain
#
###

import entity, sys
import random

class RandomFirePlayer(entity.Player, entity.Ship):

    def name_ship(self, ship):
        n = repr(ship.__class__)
        return n[n.index('.') + 1 : -2]

    def on_hit(self, x, y):
        self.x = y
        self.y = y
        if self.x >= 0 and self.y >= 0:
            _hit.append((self.x, self.y))
            return self.x, self.y
        else:
            return None
        #print Ship.fire()
        
    def orient_ship(self, ship):
        return entity.HORIZONTAL

    def place_ship(self, ship):
        # Frigate           V
        # H-Destroyer       Des
        # Missile Cruiser   troyer
        if ship.__class__ is entity.Frigate:
            return (0, self.ocean.height - 5)
            #return (0, 0)
        if ship.__class__ is entity.MissileCruiser:
            return (2, self.ocean.height - 1)
            #return (2, 2)
        if ship.orientation == entity.HORIZONTAL:
            
            return (self.ocean.width - 2, 0)
            #return (1, 1)
        return (self.ocean.width - 1, self.ocean.height - 5)
        #return (5, 1)

    def lock_missile(self, ship):
        #2 loat dan dau de ban nhung con ga neo tau theo toa do mac dinh bat chuoc con randome_fire :D
        if _count == 0:
            _count += 1
            global _count
            _hadshot.append((0, 0))
            return (0, 0)
        if _count == 1:
            _count += 1
            global _count
            _hadshot.append((3, 2))
            return (3, 2)
        if _count == 2:
            _count += 1
            global _count
            _hadshot.append((1, 1))
            return (5, 1)
        if _count == 3:
            _count += 1
            global _count
            _hadshot.append((1, 1))
            return (1, 1)
        if _count == 4:
            _count += 1
            global count
            _hadshot.append((0, 2))
            return (0, 2)
        while True:
            _toado = (random.randint(0, self.ocean.width - 1),random.randint(0, self.ocean.height - 1))
            if len(_hadshot) == 0:
                _hadshot.append(_toado)
                return _toado
            else:
                if _toado in _hadshot:
                    continue
                else:
                    _hadshot.append(_toado) 
                    return _toado
def entry(name):
    global _count
    _count = 0
    global _flag
    _flag = 1
    global _hit
    _hit =[]
    global _hadshot
    _hadshot = []
    return RandomFirePlayer(name)