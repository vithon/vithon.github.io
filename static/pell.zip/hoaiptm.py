from decimal import * # from python 2.4

getcontext().prec = 200

u = 3+2*Decimal(2).sqrt()


delta = lambda k: 8*k*k + 1
issquarenumber = lambda m: int(Decimal(m).sqrt().to_integral())**2 == m
next_k = lambda k: int(Decimal.to_integral(k*u))
nk = lambda k: (2*k-1 + int(Decimal(delta(k)).sqrt().to_integral()))/2


k = 1
while issquarenumber(delta(k)):
  n = nk(k)
  assert(n**2 + (1-2*k)*n - k*(k+1) == 0)
  print n, k
  k = next_k(k)
