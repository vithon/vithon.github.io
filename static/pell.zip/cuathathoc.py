from multiprocessing import Process, Queue, Lock

def printList(queue, lock):
    while(not queue.empty()):
        a, b = map(str,queue.get(True))
        with lock:
            print a, b

i = 1
k_1, n_1 = (1, 2)
convert_queue = Queue()
lock = Lock()

while(True):
    p1 = Process(target=printList, args=(convert_queue, lock))
    p2 = Process(target=printList, args=(convert_queue, lock))
    while i < 1000:
        k =   k_1 + 2*n_1 + 1
        n = 2*k_1 + 5*n_1 + 2
        convert_queue.put((n, k))
        k_1, n_1 = (k, n)
        i+=1
    p1.start()
    p2.start()
    p1.join()
    p2.join()
    i=1
    

