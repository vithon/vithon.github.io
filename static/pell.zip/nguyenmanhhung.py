# -*- coding: utf-8 -*-

"""
Giải bài toán  : Tìm các cặp số n,k thỏa mãn
                 1 + 2 + … + n = n + 1 + n + 2 + … + n + k

Input          : Không có.
Output         : Standard Output.
Output Format  : In trên nhiều dòng, mỗi dòng là một cặp số n, k
                 cách nhau bằng một hoặc nhiều khoảng trắng.

"""
# input:
# n,k: Số nguyên dương lớn hơn 0 (N*) ???
# Điều kiện vòng lặp: 30s ???
#
# tong = lambda n: (n + 1)*n/2
# tong2 = lambda n,k: tong(k) + k*n
#
# (n + 1)*n/2 = k*n + (k + 1)*k/2
#
# Giải phương trình:
# k*k + (2*n + 1)*k - n*(n + 1) = 0

from math import sqrt
from time import strftime, time

delta = lambda n: 8*n*n + 8*n + 1
# x1 = lambda n: (-(2*n + 1) - sqrt(delta(n)))/2
x2 = lambda n: (-(2*n + 1) + sqrt(delta(n)))/2

# Thời gian bắt đầu
print strftime('%I:%M:%S %p')
print u'========='
print u'n\tk\n \t '

# Chạy script trong thời gian quy định 30s
temp = time()+30
n = 1
while temp != time():
    if (int(x2(n)) == x2(n)):
        print u'%s\t%s' %(n, int(x2(n)))
    n += 1

# Thời gian kết thúc
print u'========='
print strftime('%I:%M:%S %p')

