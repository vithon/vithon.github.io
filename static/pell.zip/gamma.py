#!/usr/bin/env python
#c0d3d by g4mm4
n, k = 0, 0
try:
    while True:
        k += 2 * n + 1
        n += 2 * k
        print n, k
finally:
    try:
        while True:
            k += 2 * n + 1
            n += 2 * k
            print n, k
    finally:
        while True:
            k += 2 * n + 1
            n += 2 * k
            print n, k