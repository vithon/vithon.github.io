import math
k=0
while True:
	i = math.sqrt(8*k*k+1)
	i2 = int(i)
	if i2 == i:
		n = (2*k-1+i2)/2
		print n,k
	k+=1
