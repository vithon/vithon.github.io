###
#
# Author: Nguyen Thanh Nam
#
# Released to the Public Domain
#
###

from threading import Condition
from collections import defaultdict
from werkzeug import script, Request
from werkzeug.routing import Map, Rule
from werkzeug.exceptions import HTTPException
import time
import web
import pickle
import random
import subprocess
import os, sys

SECRET_KEY = web.SECRET_KEY
MATCH_RESULTS = {}
MATCH_KEYS = []
CONDITIONS = []
MODULES = ['fire_sheep', 'checker', 'randome', 'bibo']
HEADER = FOOTER = ''
RESOURCES = {}

DMP_FILE = 'battleship.pickle'

class MatchResult(object):
	def __init__(self, m1, m2):
		self.modules = (m1, m2)
		self.turns = []
		self.winners = []
		self.over = False

def preload():
	global RESOURCES
	for n in ('frigate_h.png', 'frigate_v.png', 'destroyer_h.png', 'destroyer_v.png',
		'cruiser_h.png', 'cruiser_v.png', 'bomb1.png', 'bomb2.png', 'bomb3.png',
		'fire.png', 'bullet.png'):
		with open(n, 'rb') as f:
			RESOURCES[n] = f.read()
preload()

def generate_matches():
	global MODULES, MATCH_RESULTS, MATCH_KEYS, CONDITIONS
	for i in range(len(MODULES)):
		for j in range(i + 1, len(MODULES)):
			p1 = MODULES[i]
			p2 = MODULES[j]
			key = (p1, p2)
			MATCH_KEYS.append(key)
			CONDITIONS.append(Condition())
			MATCH_RESULTS[(p1, p2)] = MatchResult(p1, p2)
generate_matches()

def load_template():
	global HEADER, FOOTER
	with open('template.html') as f:
		data = f.read()
	HEADER, test, FOOTER = data.split('<!-- TESTING -->')
load_template()

def view(request, match_id):
	global MATCH_RESULTS, MATCH_KEYS
	m = MATCH_RESULTS[MATCH_KEYS[match_id]]
	l = len(m.turns)
	if not l:
		yield '<html><head><meta http-equiv="refresh" content="5"/></head><body>Match has not been started yet.</body></html>'
		return
	yield HEADER
	for i in range(2):
		yield "<script>$('player%d').innerHTML='%s';</script>" % (i + 1, m.modules[i])
	for i in range(l):
		yield m.turns[i]
	while not m.over:
		with CONDITIONS[match_id]:
			CONDITIONS[match_id].wait()
			new_l = len(m.turns)
		for i in range(l, new_l):
			yield m.turns[l]
		l = new_l
	yield FOOTER

def view_resource(request, resource_name):
	return RESOURCES[resource_name]

def update(request, match_id):
	def init_ocean(m, x, y):
		m.turns.append('<script>var ocean = new Ocean(%d, %d); ocean.display();</script>\n' % (x, y))
	def orient_ship(m, pid, sid, o):
		m.turns.append('<script>ships[%d][%d].orient(%d);</script>\n' % (pid, sid, o))
	def place_ship(m, pid, sid, x, y):
		m.turns.append('<script>ships[%d][%d].display(%d, %d);</script>\n' % (pid, sid, x, y))
	def fire(m, pid, sid, x, y):
		m.turns.append('<script>ships[%d][%d].fire(%d, %d);</script>\n' % (pid, sid, x, y))
	def disqualify(m, pid):
		m.turns.append('<div><strong>%s is disqualified!</strong></div>' % (m.modules[pid]))
	def win(m, pid):
		m.turns.append('<div><strong>%s wins!</strong></div>' % (m.modules[pid]))
	def over(m):
		m.over = True
	global SECRET_KEY, MATCH_RESULTS, MATCH_KEYS
	if request.values.get('key') != SECRET_KEY:
		yield 'NOT OK'
		return
	try:
		m = MATCH_RESULTS[MATCH_KEYS[match_id]]
	except KeyError:
		yield 'NOT OK'
		return
	if m.over:
		yield 'NOT OK'
		return
	action = request.values.get('action')
	with CONDITIONS[match_id]:
		if action == 'init_ocean':
			x = request.values.get('x', type=int)
			y = request.values.get('y', type=int)
			init_ocean(m, x, y)
		elif action == 'place_ship':
			pid = request.values.get('pid', type=int)
			sid = request.values.get('sid', type=int)
			x = request.values.get('x', type=int)
			y = request.values.get('y', type=int)
			place_ship(m, pid, sid, x, y)
		elif action == 'orient_ship':
			pid = request.values.get('pid', type=int)
			sid = request.values.get('sid', type=int)
			orientation = request.values.get('o', type=int)
			orient_ship(m, pid, sid, orientation)
		elif action == 'fire':
			pid = request.values.get('pid', type=int)
			sid = request.values.get('sid', type=int)
			x = request.values.get('x', type=int)
			y = request.values.get('y', type=int)
			fire(m, pid, sid, x, y)
		elif action == 'disqualify':
			pid = request.values.get('pid', type=int)
			m.winners.append(1-pid)
			m.over = True
			disqualify(m, pid)
		elif action == 'win':
			pid = request.values.get('pid', type=int)
			m.winners.append(pid)
			win(m, pid)
		elif action == 'over':
			over(m)
		CONDITIONS[match_id].notify_all()
	yield 'OK'

def index(request):
	global MATCH_RESULTS, MATCH_KEYS
	scores = defaultdict(int)
	yield '<html><head><title>Battleship LIVE!</title></head><body>'
	yield '<h2>Matches</h2>'
	yield '<table border="1"><tr><th>Match</th><th>Winner(s)</th></tr>'
	for i, k in enumerate(MATCH_KEYS):
		m = MATCH_RESULTS[k]
		yield '<tr><td><a href="' + url_for("view", match_id=i) + '">' + k[0] + ' v.s. ' + k[1] + '</a></td><td>' + (','.join(m.modules[w] for w in m.winners) or '&nbsp;') + '</td></tr>'
		if len(m.winners) > 1:
			scores[m.modules[0]] += 1
			scores[m.modules[1]] += 1
		elif len(m.winners):
			scores[m.modules[m.winners[0]]] += 3
	yield '</table>'
	yield '<h2>Total Points</h2>'
	yield '<table border="1"><tr><th>Module</th><th>Points</th></tr>'
	for m, p in scores.iteritems():
		yield '<tr><td>%s</td><td>%d</td></tr>' % (m, p)
	yield '</table>'
	yield '</body></html>'

def dump(request):
	global MATCH_RESULTS, MATCH_KEYS
	with open(DMP_FILE, 'wb') as f:
		pickle.dump((MATCH_RESULTS, MATCH_KEYS), f)
	return 'OK'

def load(request):
	global MATCH_RESULTS, MATCH_KEYS
	with open(DMP_FILE, 'rb') as f:
		MATCH_RESULTS, MATCH_KEYS = pickle.load(f)
	return 'OK'

def debug(request, match_id):
	global MATCH_RESULTS, MATCH_KEYS
	m = MATCH_RESULTS[MATCH_KEYS[match_id]]
	return '\n'.join(m.turns)

def start(request):
	match_id = int(request.values.get('match_id', '0'))
	if not request.values.get('key'):
		return '<form method="post">Match ID: <input type="text" name="match_id" value="%d"/>Key: <input type="password" name="key" value=""/>Delay: <input type="text" name="delay" value="10"/><input type="submit"/></form>' % match_id
	global SECRET_KEY, MATCH_KEYS
	key = request.values.get('key')
	if key != SECRET_KEY:
		return 'NOT OK'
	x = random.randint(10, 15)
	y = random.randint(10, 15)
	cwd = os.path.dirname(os.path.abspath(__file__))
	launcher_path = os.path.join(cwd, 'launcher.py')
	left, right = MATCH_KEYS[match_id]
	delay = request.values.get('delay')
	live = int(delay)
	environ = os.environ.copy()
	environ['MATCH_ID'] = str(match_id)
	cmd = [sys.executable, launcher_path, '-1', left, '-2', right, '-l', str(live), '-v', 'web', '-x', str(x), '-y', str(y)]
	subprocess.Popen(cmd, cwd=cwd, env=environ, close_fds=True)
	return 'OK'

url_map = Map([
    Rule('/', endpoint='index'),
    Rule('/view/<int:match_id>', endpoint='view'),
    Rule('/view/<resource_name>', endpoint='view_resource'),
    Rule('/update/<int:match_id>', endpoint='update'),
    Rule('/debug/<int:match_id>', endpoint='debug'),
    Rule('/dump', endpoint='dump'),
    Rule('/load', endpoint='load'),
    Rule('/start', endpoint='start'),
])
url_adapter = None

views = {'index': index, 'update': update, 'view': view,
	'view_resource': view_resource, 'dump': dump, 'load': load,
	'debug': debug, 'start': start}

def url_for(endpoint, **values):
	return url_adapter.build(endpoint, values)

def app(environ, start_response):
	global url_adapter
	url_adapter = url_map.bind_to_environ(environ)
	request = Request(environ)
	try:
		endpoint, args = url_adapter.match()
	except HTTPException, e:
		return e(environ, start_response)
	# this is bad, but hey no time... :-D
	if endpoint.endswith('resource'):
		start_response('200 OK', [('Content-Type', 'image/png')])
	elif endpoint.endswith('debug'):
		start_response('200 OK', [('Content-Type', 'text/plain')])
	else:
		start_response('200 OK', [('Content-Type', 'text/html')])
	return views[endpoint](request, **args)

def make_app():
	return app

action_runserver = script.make_runserver(make_app, use_reloader=True, threaded=True)
script.run()