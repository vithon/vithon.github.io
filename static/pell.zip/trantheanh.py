import math;

k=1;
m=8*k*k+1;
d=math.sqrt(8);

while True:
	t = int(math.floor(d*k));
	p1 = t*t;
	p2 = p1+2*t+1;
	if (p1 == m or p2 == m):
		if (p2 == m):
			t = t+1;
		print int((t+2*k-1) / 2), int(k);
		k = int(k * 2108646576008245 / 361786555939836);
		m = 8*k*k+1;
	else:
		k = k+1;
		m = 8*k*k+1;
