###
#
# Battle Ship game sample player
#
# Author: Nguyen Thanh Nam
#
# Released to the public domain
#
###

import random

import entity

class RandomFirePlayer(entity.Player):

    HitList = []
    ShotList = []

    def invalid_point(self, x, y, ship):
        if x < 0 or x >= self.ocean.width:
            return True
        if y < 0 or y >= self.ocean.height:
            return True
        if ship.__class__ is entity.Frigate:
            if (x, y) in self.ShotList:
                return True
            else:
                return False
        if ship.__class__ is entity.MissileCruiser:
            if (x, y) in self.ShotList or (x-1, y) in self.ShotList or (x+1, y) in self.ShotList or (x, y-1) in self.ShotList or (x, y+1) in self.ShotList:
                return True
            else:
                return False
              
        if ship.orientation == entity.HORIZONTAL:
            if (x, y) in self.ShotList or (x-1, y) in self.ShotList or (x+1, y) in self.ShotList:
                return True
            else:
                return False
        if ship.__class__ is entity.Destroyer:
            if (x, y) in self.ShotList or (x, y-1) in self.ShotList or (x, y+1) in self.ShotList:
                return True
            else:
                return False

        return False

    def fire_random(self, ship):
        #if len(self.ShotList) == 0:
        while True:
            (x, y) = (random.randint(0, self.ocean.width - 1),
                    random.randint(0, self.ocean.height - 1))
            #if self.invalid_point(x, y, ship) == False:
            self.ShotList.append((x, y))
            return (x, y)

        #if len(self.ShotList) != 0:
        #    return self.fire_adjacent(ship)


    def fire_target(self, ship):

        while True:
            (x, y) = self.HitList[len(self.HitList) - 1]

            if ship.__class__ is entity.Frigate:
                if self.invalid_point(x-1, y, ship) == False:
                    self.ShotList.append((x-1, y))
                    return (x-1, y)
                elif self.invalid_point(x+1, y, ship) == False:
                    self.ShotList.append((x+1, y))
                    return (x+1, y)
                elif self.invalid_point(x, y-1, ship) == False:
                    self.ShotList.append((x, y-1))
                    return (x, y-1)
                elif self.invalid_point(x, y+1, ship) == False:
                    self.ShotList.append((x, y+1))
                    return (x, y+1)

            elif ship.__class__ is entity.MissileCruiser:
                if self.invalid_point(x-2, y, ship) == False:
                    self.ShotList.append((x-2, y))
                    self.ShotList.append((x-2, y-1))
                    self.ShotList.append((x-2, y+1))
                    self.ShotList.append((x-3, y))
                    self.ShotList.append((x-1, y))
                    return (x-2, y)
                elif self.invalid_point(x+2, y, ship) == False:
                    self.ShotList.append((x+2, y))
                    self.ShotList.append((x+2, y-1))
                    self.ShotList.append((x+2, y+1))
                    self.ShotList.append((x+3, y))
                    self.ShotList.append((x+1, y))
                    return (x+2, y)
                elif self.invalid_point(x, y-2, ship) == False:
                    self.ShotList.append((x, y-2))
                    self.ShotList.append((x+1, y-2))
                    self.ShotList.append((x-1, y-2))
                    self.ShotList.append((x, y-1))
                    self.ShotList.append((x, y-3))
                    return (x, y-2)
                elif self.invalid_point(x, y+2, ship) == False:
                    self.ShotList.append((x, y+2))
                    self.ShotList.append((x+1, y+2))
                    self.ShotList.append((x-1, y+2))
                    self.ShotList.append((x, y+1))
                    self.ShotList.append((x, y+3))
                    return (x, y+2)

            elif ship.orientation == entity.HORIZONTAL:
                if self.invalid_point(x-2, y, ship) == False:
                    self.ShotList.append((x-2, y))
                    self.ShotList.append((x-3, y))
                    self.ShotList.append((x-1, y))
                    return (x-2, y)
                elif self.invalid_point(x+2, y, ship) == False:
                    self.ShotList.append((x+2, y))
                    self.ShotList.append((x+3, y))
                    self.ShotList.append((x+1, y))
                    return (x+2, y)

            elif ship.__class__ is entity.Destroyer:
                if self.invalid_point(x, y-2, ship) == False:
                    self.ShotList.append((x, y-2))
                    self.ShotList.append((x, y-1))
                    self.ShotList.append((x, y-3))
                    return (x, y-2)
                elif self.invalid_point(x, y+2, ship) == False:
                    self.ShotList.append((x, y+2))
                    self.ShotList.append((x, y+1))
                    self.ShotList.append((x, y+3))
                    return (x, y+2)

            self.HitList.pop()
            if len(self.HitList) < 1:
                return self.fire_random(ship)

    def name_ship(self, ship):
        n = repr(ship.__class__)
        return n[n.index('.') + 1: -2]

    def on_hit(self, x, y):
        self.HitList.append((x, y))

    def orient_ship(self, ship):
        return entity.VERTICAL

    def place_ship(self, ship):
        # Frigate           V
        # H-Destroyer       Des
        # Missile Cruiser   troyer
        if ship.__class__ is entity.Frigate:
            return (2, self.ocean.height - 2)
        if ship.__class__ is entity.MissileCruiser:
            return (self.ocean.height - 2, 3)
        if ship.orientation == entity.HORIZONTAL:
            return (self.ocean.height - 4, 8)
        return (self.ocean.height - 2, 7)

    def lock_missile(self, ship):
        if len(self.HitList) < 1:
            return self.fire_random(ship)
        else:
            return self.fire_target(ship)

def entry(name):
    return RandomFirePlayer(name)


