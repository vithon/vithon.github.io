# -*- coding: utf-8 -*-
"""
Created on Sat Dec 11 22:50:03 2010

checker.py
"""


import entity
import random


class Checker(entity.Player):

    def name_ship(self, ship):
        n = repr(ship.__class__)
        return n[n.index('.') + 1 : -2]

    def on_hit(self, x, y):
        self.x = x
        self.y = y
        if (self.x, self.y):
            fired.add((self.x, self.y))

    def orient_ship(self, ship):
        return entity.HORIZONTAL

    def place_ship(self, ship):
        if ship.__class__ is entity.Frigate:
            return (0, 0)
        if ship.__class__ is entity.MissileCruiser:
            return (1, 7)
        if ship.orientation == entity.HORIZONTAL:
            return (1, 1)
        return (5, 1)

    def lock_missile(self, ship):
        if not fired:
            return (random.randint(0, self.ocean.width - 1), random.randint(0, self.ocean.height - 1))
        else:
            checker = None
            while checker == None :
                fire = (random.randint(0, self.ocean.width - 1), random.randint(0, self.ocean.height - 1))
                if fire in fired:
                    continue
                else:
                    checker = 1
                    return fire

def entry(name):
    global fired
    fired = set()
    return Checker(name)
