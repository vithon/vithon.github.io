###
#
# Battle Ship game sample player
#
# Author: Nguyen Thanh Nam
#
# Released to the public domain
#
###

import entity
import random

class RandomFirePlayer(entity.Player):

	def name_ship(self, ship):
		n = repr(ship.__class__)
		return n[n.index('.') + 1 : -2]

	def on_hit(self, x, y):
		# dont care
		pass

	def orient_ship(self, ship):
		return entity.HORIZONTAL

	def place_ship(self, ship):
		# Frigate           V
		# H-Destroyer       Des
		# Missile Cruiser   troyer
		if ship.__class__ is entity.Frigate:
			return (0, 0)
		if ship.__class__ is entity.MissileCruiser:
			return (2, 2)
		if ship.orientation == entity.HORIZONTAL:
			return (1, 1)
		return (5, 1)

	def lock_missile(self, ship):
		return (random.randint(0, self.ocean.width - 1),
			random.randint(0, self.ocean.height - 1))	

def entry(name):
	return RandomFirePlayer(name)
