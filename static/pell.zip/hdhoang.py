#!/usr/bin/python

from signal import signal, alarm, SIGALRM
alarm(30)
from sys import exit
signal(SIGALRM, lambda _, __: exit(14))

from decimal import Decimal, getcontext, InvalidOperation
ctx = getcontext()
two = Decimal(2)
m = Decimal(1)

while True:
    sr2 = two.sqrt()
    try:
        k = abs((((3 - 2*sr2)**m - (3 + 2*sr2)**m)/(4*sr2)).quantize(m))
        n = (((8*k**2+1).sqrt() + 2*k - 1) / 2).quantize(m)
        assert 2*k*k == (n-k)*(n-k+1)
    except (AssertionError, InvalidOperation):
        ctx.prec += 1
        continue
    else:
        print n, k
    m += 1
