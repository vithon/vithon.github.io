'''
Created on May 25, 2010
@author: namnx
'''
import os
from multiprocessing import Process, Queue
NUMBER_OF_PROCESSES = 5


def convert(result_queue, output_queue):
	while True:
		n, k = result_queue.get()
		s = str(n) + ' ' + str(k) + '\n'
		output_queue.put(s)
		

def output(output_queue):
	while True:
		s = output_queue.get()
		os.write(1, s)


if __name__ == '__main__':
	k = n = 0
	result_queue = Queue(1000)
	output_queue = Queue(1000)
	for i in range(NUMBER_OF_PROCESSES):
		Process(target = convert, args=(result_queue, output_queue)).start() 
	Process(target = output, args=(output_queue, )).start()
	
	while True:
		k += 2*n + 1
		n += 2*k
		result_queue.put([n,k])
