import signal
import os
import subprocess
import sys
import time

def alrm(x, y):
	subprocess.Popen(['/bin/killall', 'python']).wait()

signal.signal(signal.SIGALRM, alrm)

if os.fork() == 0:
	subprocess.Popen(['python', sys.argv[1]]).wait()
	sys.exit(0)

signal.alarm(30)
time.sleep(30)
alrm(0, 0)
sys.exit(0)
