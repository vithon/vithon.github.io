"""
Bai du thi: Giai toan bang Python - www.vithon.org
Thi sinh: Le Truong Vinh Phu
Email   : le.truong.vinh.phu@gmail.com
Mobile  : 0907 194 823

Nhan xet quy luat:
    Phuong trinh bac 2 co dang: n*n + (1 - 2k)*n - k*k -k = 0
    Delta = 8*k*k + 1 > 0 voi moi k nguyen duong
- Day so k: k(n) = 6 * k(n-1) - k(n-2)
- Day so sqrt(delta) - goi la x: x(n) = 6 * x(n-1) - x(n-2)
=> Giai thuat tinh toan nhanh: tinh ra day k va x tuong ung, tu do tinh ra n ma khong can dung sqrt()
   n = (2*k - 1 + x)/2

"""
from sys import stdout
from math import sqrt
x1 = 0
x2 = 0
k1 = 0
k2 = 0

# vong lap dau tien de tinh cac gia tri khoi tao cho day truy hoi
i = 0
while True:
    flag = False
    i += 1
    delta = 8*i*i + 1 # delta = 8 k*k + 1
    
    # kiem tra so chinh phuong hoan hao
    h = delta & 0xf
    if h > 9:
         flag = False
    elif (h != 2) and (h != 3) and (h != 5) and (h != 6) and (h != 7) and (h != 8):
        t = sqrt(delta)
        flag = int(t) == t
    # neu delta la so chinh phuong hoan hao    
    if flag:
        if x1 == 0: # thanh cong lan dau tien: khoi tao x1, k1
            x1 = int(t)
            k1 = i
            stdout.write('%d %d\n' % ((2*k1 - 1 + x1)/2,k1))
            continue
        else: # thanh cong lan thu 2: khoi tao x2, k2 va thoat vong lap
            x2 = int(t)
            k2 = i
            stdout.write('%d %d\n' % ((2*k2 - 1 + x2)/2,k2))
            break    

# vong lap thu hai tinh day truy hoi tu cac gia tri bien ban dau
while True:
    x = 6 * x2 - x1    
    k = 6 * k2 - k1
    stdout.write('%d %d\n' % ((2*k - 1 + x)/2,k))
    x1 = x2
    x2 = x
    k1 = k2
    k2 = k

