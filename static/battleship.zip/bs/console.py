###
#
# Battle Ship game console display
#
# Author: Nguyen Thanh Nam
#
# Released to the public domain
#
###

import pprint
import entity

def ship_to_ascii(s):
	if s.__class__ == entity.Frigate:
		return 'F'
	if s.__class__ == entity.Destroyer:
		return 'D'
	return 'M'

def ocean_to_ascii(ocean):
	ascii = []
	for row in range(ocean.height):
		line = []
		for col in range(ocean.width):
			s = ocean.get_ship(col, row)
			if ocean.is_mark(col, row) == entity.BOMBARDED:
				line.append('X')
			elif not s:
				line.append('.')
			else:
				line.append(ship_to_ascii(s))
		ascii.append(line)
	return ascii

class View(object):

	def __init__(self):
		self.pp = pprint.PrettyPrinter()

	def display_oceans(self, oceans):
		o1 = ocean_to_ascii(oceans[0])
		o2 = ocean_to_ascii(oceans[1])
		for i, line in enumerate(o1):
			print ''.join(line), '|', ''.join(o2[i])
		print '-' * (len(line) * 2 + 3)

	def init(self, game):
		print "Initial map"
		self.display_oceans(game.oceans)

	def lock_missile(self, game, pid, sid, x, y):
		player = game.players[pid]
		ship = game.ships[pid][sid]
		print "%s locked missile on (%d, %d) from %s" % (player.name, x, y, ship)

	def end_turn(self, game):
		self.display_oceans(game.oceans)

	def disqualify(self, game, pid):
		player = game.players[pid]
		print "%s is disqualified!" % player.name

	def over(self, game):
		print "THE GAME IS OVER!!!"

	def winner(self, game, pid):
		player = game.players[pid]
		print "%s is the winner!" % player.name

def entry():
	return View()
